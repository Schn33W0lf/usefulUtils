PICTURE SORTER
 pre-release alpha v de_0.3
LANG:		de_DE
SORTIERT:	aufnahme- erstell datum, (durchnummerieren)
DEV:		(C)Schn33W0lf
BENUTZT:	ExifTool by Phil Harvey
ICON:		http://www.iconarchive.com/show/100-flat-2-icons-by-graphicloads/file-folder-icon.html
INSTALLATION:	nein
O.S. BATCH:	ja, gleiche version
(Open.Source.)